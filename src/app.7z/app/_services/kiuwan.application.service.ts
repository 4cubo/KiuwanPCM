import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {of} from 'rxjs/observable/of';

import {Kiuwanapplication, KiuwanApplicationAnalisys, KiuwanApplicationDelivery} from '../classes/kiuwanapplication';
import {MessageService} from '../message.service';
import {appConfig} from '../app.config';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class KiuwanApplicationService {

  constructor(
    private messageService: MessageService,
    private http: HttpClient
  ) {
    console.log("Constructor de KiuwanApplicationService[Service]"); //@aaa delete
  }

  applications: Kiuwanapplication[]; //@aaa mock-applications

  kiuwanUser: string = '';
  kiuwanPasswd: string = '';


  setCredentials = function(userName, passwd) {
    console.log(" setCredentials:" + userName + "/" + passwd);
    this.kiuwanUser = userName;
    this.kiuwanPasswd = passwd;
    this.messageService.add('Kiuwan App Service: credentials configured');

  };


  getApplications(): Observable<Kiuwanapplication[]> {

    // Todo: send the message _after_ fetching the applications
    this.messageService.add('Kiuwan App Service: getApplications');

    if (this.applications) {
      console.log('----------------------------_>Recuerado aplicaciones kiuwan del propio servicio');
      return of(this.applications);
    }
    // @aaa @TODO Do not use LocalStorage in the future, session storage or server mongo instead
    let apps: Kiuwanapplication[] =  
      JSON.parse(localStorage.getItem('KiuwanApplications'));
    if (apps) {
      console.log('----------------------------_>Recuerado aplicaciones kiuwan del local storage');
      return of(apps);
    }

    console.log('----------------------------_>Recuerado aplicaciones kiuwan de kiuwan');

    let data = {
      method: 'GET',
      url: "/apps/list",
      headers: {
        'Authorization': 'Basic ' + window.btoa(this.kiuwanUser + ':' + this.kiuwanPasswd)
        // 'Target_URL': 'https://api.kiuwan.com',
        // 'Content-Type': 'application/json; charset=UTF-8'
      }
    };


    return this.http.post<Kiuwanapplication[]>(appConfig.apiUrl + '/kiuwan', data)
      .map(kiuApps => {
        console.log('Lista de apps recibida:', kiuApps);
//        for (let i = 0; i < kiuApps.length; i++) {
//          let item : Kiuwanapplication  = kiuApps[i] as Kiuwanapplication;
//          console.log ("--------->", item);
//          Kiuwanapplication.explodeData(item);
//        }
//        localStorage.setItem('KiuwanApplications', JSON.stringify(kiuApps));
        this.applications = kiuApps;
        return kiuApps;
      });

  }


  // Return analisys and last_analisys
  getApplication(name: string): Observable<Kiuwanapplication> {
    // Todo: send the message _after_ fetching the hero
    this.messageService.add(`ApplicationProviderService: fetched application name=${name}`);
    //    return of(MOCK_APPLICATIONS.find(app => app.id === id));

    let result: Kiuwanapplication;
    //let analisys: KiuwanApplicationAnalisys[];

    this.getApplications().subscribe(
      apps => {
        result =  apps.find(app => app.name === name);
      }
    );

    this.getApplicationsAnalisys(name).subscribe(
      appAna => {
        result['ANALISYS']=  appAna;
      }
    );

    this.getApplicationDeliverys(name).subscribe(
      appAna => {
        result['DELIVERIES']=  appAna;
      }
    );
    
    

    
    // Return a promise
    return of(result);
    //return (result);
  }




  getApplicationsAnalisys( appName : string ): Observable<KiuwanApplicationAnalisys[]> {
    this.messageService.add('Kiuwan App Service: getApplicationsAnalisys');

    // @aaa @TODO Do not use LocalStorage in the future, session storage or server mongo instead
    
    let appAnalisys: KiuwanApplicationAnalisys[]=
      JSON.parse(localStorage.getItem('KiuwanApplicationAnalisys_' + encodeURI(appName)));
    if (appAnalisys) {
      console.log('----------------------------_>Recuperando anlaisis de la app. kiuwan ', appName ,' de local storage');
      return of(appAnalisys);
    }

    console.log('----------------------------_>Recuperando analisis app[', appName,'] de kiuwan');

    let data = {
      method: 'GET',
      url: '/apps/'+encodeURI(appName)+'/analyses',
      headers: {
        'Authorization': 'Basic ' + window.btoa(this.kiuwanUser + ':' + this.kiuwanPasswd)
      }
    };


    return this.http.post<KiuwanApplicationAnalisys[]>(appConfig.apiUrl + '/kiuwan', data)
      .map(kiuAppAnas => {
        console.log('Lista de analisis recibida:', kiuAppAnas);
        //this.applications = kiuApps;
        localStorage.setItem('KiuwanApplicationAnalisys_' + encodeURI(appName), JSON.stringify( kiuAppAnas) );
        return kiuAppAnas;
      });

  }


  

  getApplicationDeliverys( appName : string ): Observable<KiuwanApplicationDelivery[]> {
    this.messageService.add('Kiuwan App Service: getApplicationDeliveries');

    // @aaa @TODO Do not use LocalStorage in the future, session storage or server mongo instead
    
    let appAnalisys: KiuwanApplicationDelivery[]=
      JSON.parse(localStorage.getItem('KiuwanApplicationDelivery_' + encodeURI(appName)));
    if (appAnalisys) {
      console.log('----------------------------_>Recuperando deliveries de la app. kiuwan ', appName ,' de local storage');
      return of(appAnalisys);
    }

    console.log('----------------------------_>Recuperando deliveries app[', appName,'] de kiuwan');

    let data = {
      method: 'GET',
      url: '/apps/'+encodeURI(appName)+'/deliveries',
      headers: {
        'Authorization': 'Basic ' + window.btoa(this.kiuwanUser + ':' + this.kiuwanPasswd)
      }
    };


    return this.http.post<KiuwanApplicationDelivery[]>(appConfig.apiUrl + '/kiuwan', data)
      .map(kiuAppAnas => {
        console.log('Lista de deliveries recibida:', kiuAppAnas);
        //this.applications = kiuApps;
        localStorage.setItem('KiuwanApplicationDelivery_' + encodeURI(appName), JSON.stringify( kiuAppAnas) );
        return kiuAppAnas;
      });

  }


}


