import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-board-panel',
  templateUrl: './dash-board-panel.component.html',
  styleUrls: ['./dash-board-panel.component.css']
})
export class DashBoardPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
